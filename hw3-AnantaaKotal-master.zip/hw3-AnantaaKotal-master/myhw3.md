# Anantaa Kotal, ANANTAK1@UMBC.EDU

1. Created a myfamily.n3 with details about 12 members of my family, including grandparents.
Details of each individual includes their: givenName, Birth, spouseIn, childIn, siblings and parents.

2. Created the following rules about the family in myrules.n3:
i. All individuals with different given name are different from each other.
ii. A person knows their child, grandchild, sibling, parents and grandparents.
iii. A person is younger than their parents and grandparents.
iv. A person is older than their children and grandchildren.

3. Made myfamilyfacts.ttl using the makefile.
