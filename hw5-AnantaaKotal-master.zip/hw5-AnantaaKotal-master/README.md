# Homework Five: Writing SPARQL Queries


### out Monday 2019-11-25, due Friday 2019-12-13

This homework will give you some experience in using the RDF query language SPARQL to access the linked open data collections DBpedia and WIkidata.

To use the python script sparql.py you will need to install [SPARQLWrapper](https://pypi.org/project/SPARQLWrapper/) on your computer with the command
```
pip install SPARQLWrapper
```
If you need to do this on a system where you do not have privileges to intall python packages (like gl.umbc.edu) you can use the --user flag:
```
pip install SPARQLWrapper --user 
```

This repository has a stub for each of the queries you have to write with a name like q??.txt or w?.txt. Edit each stub to be a working query, verifying that it works using a web based sparql client like the one at [http://dbpedia.org/sparql](http://dbpedia.org/sparql) or [yasgui](http://yasgui.org/) for the DBpedia queries and the [Wikidata query service](https://query.wikidata.org/) for the Wikidata queries, or just use the python script sparql.py to run the query and produce output files.

When you are done, you can rerun all of your queries with a command like
```
python sparql.py *.txt
```
Be sure to commit your final input and output (*.txt, *.txt.html and *.txt.json files) to your repository files and push them back to the master on github.


