# HW4 notes
There are two main classes, AbstractObject and PhysicalObject, that are disjoint to each other.
PhysicalObject can be Inanimate object or animate object.
Organization and Place are subclasses of AbstractObject.
SexualReproducers are a subclass of physical object and Person is a subclass of sexualreproducer.
Subclasses of persons are adultwoman, adultman, boy, girl, child and infant.
Infant is disjoint from child, adultman and adultwoman.
The dataproperties are: SSN, age, sex, latitude, longitude and name.
Objectproperties are: parent (mother and father are subproperties of parent), grandparent, employer, location.
An employer can be an organization.
A location can be a place.
If an organization has the properties of latitude and logitude, it can also be inferred as a place. 
