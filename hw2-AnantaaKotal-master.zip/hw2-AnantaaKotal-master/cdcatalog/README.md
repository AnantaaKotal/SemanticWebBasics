# CD Catalog XML example

A simple example of using XML for reporesenta data about a CD clooection consisting of a

* cdcatalog.xml -- an example of some data for a CD collection 

* cdcatalog.xsd -- an Xml schema file that describes the structure a cdcatalog.xml file should follow

* cdcatalog.xsl -- a style sheet that will produce HTML from the xml data
