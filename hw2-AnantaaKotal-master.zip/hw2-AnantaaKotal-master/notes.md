
The XML was transformed to an HTML file using [FreeFormatter](https://www.freeformatter.com/xsl-transformer.html)
The HTML was rendered using [HTML Editor](https://html-online.com/editor/)