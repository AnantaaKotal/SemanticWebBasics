# Expense report example

An simple example of using XML for an expense report

* expenses.xml is the data for an expense report
* ExpReport.xsd  is the XML schema file
* ExpReport.xsl is the XSL tranform file

